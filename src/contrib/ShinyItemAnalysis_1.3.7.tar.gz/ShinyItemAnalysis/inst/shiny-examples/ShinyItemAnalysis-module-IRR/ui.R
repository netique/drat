ui <- tagList(
  tags$head(
    tags$link(
      rel = "shortcut icon",
      href = "favicon.ico"
    ),
    tags$style(
      type = "text/css",
      "body {padding-top: 110px; padding-bottom: 90px; margin-left: 30px; margin-right: 30px;}"
    )
  ),
  navbarPage(
    windowTitle = "Range-restricted Reliability Showcase",
    title = tags$div(
      class = "row",
      tags$div(
        class = "col-sm-2 align-self-center",
        tags$img(src = "header_hexbin.png", height = "55px")
      ),
      tags$div(
        class = "col-sm-10 align-self-center",
        tags$b("Psychometrics Modules", style = "font-size: x-large;"), br(),
        tags$i("Range-restricted Reliability Showcase"),
        style = "line-height: 18pt;"
      )
    ),
    position = "fixed-top", # fixed header
    tags$footer(
      class = "row fixed-bottom bg-light p-3",
      tags$div(
        class = "col ml-1 align-self-center",
        style = "-ms-flex: 0 0 0px; flex: 0 0 0px;",
        tags$img(src = "hexbin.png", height = "43px")
      ),
      tags$div(
        class = "col pl-0 text-muted align-self-center",
        tags$span("Powered by", tags$a("ShinyItemAnalysis: Test and Item Analysis via Shiny",
          href = "https://shiny.cs.cas.cz/ShinyItemAnalysis/"
        ), paste0(
          "(version ",
          as.character(packageVersion("ShinyItemAnalysis")), ")"
        ),
        class = "d-block"
        ),
        tags$span(
          "©", format(Sys.Date(), "%Y"), "ShinyItemAnalysis"
        ),
        style = "line-height: 16pt;"
      )
    ),
    theme = bs_theme(bootswatch = "cerulean"),
    selected = "", # get rid of highlighting empty tab
    tabPanel(tags$a(icon("home"), "Go to the main ShinyItemAnalysis app",
      href = "https://shiny.cs.cas.cz/ShinyItemAnalysis/", target = "_blank"
    )),

    # description -------------------------------------------------------------

    p(
      "This module illustrates the issue of range-restricted reliability and
      the difficulties with maximum likelihood estimation, described in more
      detail in the context of inter-rater reliability in grant proposal review
      in",
      a(
        "Erosheva, Martinkova, & Lee (2021)",
        href = "http://doi.org/10.1111/rssa.12681",
        target = "_blank", .noWS = "after"
      ), ". We use their AIBS grant proposal peer-review dataset for presentation."
    ),
    p(
      "Below, you may select the ratio and type of range restriction given by the",
      strong("proportion of rated proposals", .noWS = "after"), ".",
      "In contexts other than grant review, the subject/object of interest may be different:
      a student in educational assessment, a job application
      in hiring, a patient in a medical study, etc. Further, you may select the",
      strong("direction"), "of restriction (top or bottom). The left plot illustrates
      the variability in ratings for the whole dataset outshading the data which
      would be lost due to range-restriction. The right plot provides the estimates
      of the calculated inter-rater reliability estimates, defined by intraclass
      corelation in the simplest model including the ratee effect only. The estimates
      are accompanied by a bootstrapped 95% confidence interval based on 25 bootstrap samples.",
      class = "mb-5"
    ),


    # UI ----------------------------------------------------------------------

    fluidRow(
      column(
        4, sliderInput(
          inputId = "reliability_restricted_proportion",
          label = "Proportion",
          min = 0,
          max = 100,
          step = 1,
          value = 100,
          animate = animationOptions(2000),
          post = "%", width = "100%"
        )
      ),
      column(
        2, selectInput(
          inputId = "reliability_restricted_direction",
          label = "Direction",
          choices = c("top", "bottom"),
          selected = "top"
        )
      ),
      column(
        2, actionButton(
          inputId = "reliability_restricted_clear",
          label = "Clear everything",
          icon = icon("eraser")
        ),
        class = "align-self-center pb-4"
      )
    ),
    fluidRow(
      column(6, plotlyOutput("reliability_restricted_caterpillarplot")),
      column(6, plotlyOutput("reliability_restricted_iccplot")),
      style = "padding-bottom: 20px;"
    ),


    # plots -------------------------------------------------------------------

    fluidRow(
      class = "mb-4", # margin after the row
      column(
        6,
        downloadButton("DB_reliability_restricted_caterpillarplot",
          label = "Download figure"
        )
      ),
      column(
        6,
        downloadButton("DB_reliability_restricted_iccplot",
          label = "Download figure"
        ),
        downloadButton("DB_reliability_restricted_iccdata",
          label = "Download data"
        )
      )
    ),


    # interpretation ----------------------------------------------------------

    h4("Interpretation"),
    fluidRow(column(
      12,
      textOutput("icc_text"),
    ), class = "mb-4"),


    # sample R code -----------------------------------------------------------

    h4("Selected R code"),
    pre(includeText("sc/reliability/restr_range.R"), class = "mb-4")
  ),

  # dedication -------------------------------------------------------------
  h4("Acknowledgements"),
  p(
    "The Psychometrics Modules are supported by Czech Science Foundation under grant ",
    a(
      "21-03658S",
      href = "http://www.cs.cas.cz/comps/projectTheorFoundComPs.html",
      target = "_blank", .noWS = "after"
    ), ". Lee and Erosheva's contributions to the development of this module and
    the data collection were further supported by the NSF the National Science
    Foundation under Grant Number 1759825.", br(), "Disclaimer:
    Any opinions, findings, and conclusions or recommendations expressed in this
    material are those of the author(s) and do not necessarily reflect the views
    of the National Science Foundation. "
  )
)
