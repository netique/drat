$(document).ready(function () {

  $( "ul.dropdown-menu > li" ).click(function() {

    $(window).scrollTop(0);

  });

});
