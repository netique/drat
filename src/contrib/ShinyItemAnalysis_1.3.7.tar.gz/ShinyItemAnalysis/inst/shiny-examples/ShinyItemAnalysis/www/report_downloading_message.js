$(function() {

    $('#download_report_button').click(function() {
        alert(
          'Downloading of reports takes some time. Please, be patient and ' +
		  'do not change the settings of application before the download ' +
		  'is completed. \n \n (Press "OK" to start report downloading.)'
        );
		/*setInterval();*/
    });

});
