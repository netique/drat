$(function() {

    $('#generate').click(function() {
        alert(
          'Generating of reports takes some time. Please, be patient and ' +
		  'do not change the settings of application before the generating ' +
		  'is completed. A download button will occure when the report is ' +
		  'ready. \n \n (Press "OK" to start report generating.)'
        );
		/*setInterval();*/
    });

});
